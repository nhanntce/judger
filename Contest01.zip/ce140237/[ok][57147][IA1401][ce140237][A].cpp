#include <bits/stdc++.h>

using namespace std;

int main() {
	freopen("A.inp", "r", stdin);
	freopen("A.out", "w", stdout)
	int test;
	cin >> test;
	while (test--) {
        long long n;
        cin >> n;
        cout << n+1 << endl;
	}
	return 0;
}
