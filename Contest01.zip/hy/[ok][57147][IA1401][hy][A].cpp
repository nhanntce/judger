#include <bits/stdc++.h>

using namespace std;

int arr[1000000000];
int main() {
	freopen("A.inp", "r", stdin);
	freopen("A.out", "w", stdout);
	int test;
	cin >> test;
	while (test--) {
        long long n;
        cin >> n;
        cout << n+1 << endl;
	}
	return 0;
}
