#include <stdio.h>

int main() {
	freopen("A.inp", "r", stdin);
	freopen("A.out", "w", stdout);
	//int test;
	//scanf("%d", &test);
	//scanf("%d", &test); 

	return 0;
}
