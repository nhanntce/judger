import java.util.Scanner;
import java.util.Arrays;
public class HelloWorld {
    /**
     * main function
     * */
    public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        long[] arr = new long[n];
        for (int i = 0; i < n; i++) {
            arr[i] = s.nextLong();
        }
        //call library to sort array
        Arrays.sort(arr);
        if (arr.length == 1) {
            System.out.print(arr[arr.length - 1]);
        } else {
            for (int i = 0; i < arr.length - 1; i++) {
                System.out.print(arr[i] + " ");
            }
            System.out.print(arr[arr.length - 1]);
        }
    }
}